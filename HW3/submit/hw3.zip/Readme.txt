Test instructions:

1. Open Visual Studio and go to file->new
2. In the name file something like my UNI fl2312
3. Select "empty project" on the list of application types
4. Click OK
5. On the right hand side, there should be a project frame named under fl2312,e.g: Solution 'fl2312'
6. Under the title there are by default four folders: Header Files, Resource Files, Source Files, and External Dependencies. Right click "Header Files" and select add->add existing items
7. Browse to select the folder you unziped my hw.Go to include folder in the main folder. You can use normal ctrl-a to select all of the headers at once. Click OK.
8. Right click Resource files and do the same to add main.cpp
9. Right click Source files and select all the *.cpp
10. Short key F-5 will start testing the file. All tasks fulfilled.

Note that:
If you have any question with regard to this hw, please feel free to call me at 9176557918 or e-mail me at fl2312@columbia.edu.
Have a good day!
