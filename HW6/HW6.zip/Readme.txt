Test instructions:

Open the CrankNocolsonFDMain.m (the main) script in the Matlab tool bar click the button with a green arrow sign. It is the run button and Matlab will prompt to ask if change the directory to current folder. Click yes, then all files in this folder is loaded to Matlab windows. Press F5 or ctrl+enter will excute the script and get the result.

Note that:
If you have any question with regard to this hw, please feel free to call me at 9176557918 or e-mail me at fl2312@columbia.edu.
Have a good day!
