#ifndef __COVARIANCE_H__
#define __COVARIANCE_H__
	#ifndef __MATH_H__
	#include <math.h>
	#endif
double cov(double *,double *,int,double mean_x,double mean_y);

#endif