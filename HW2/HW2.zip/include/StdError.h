#ifndef __STDERROR_H__
#define __STDERROR_H__
	#ifndef __MATH_H__
	#include <math.h>
	#endif
double GetStdError(double *,double,int);
#endif
